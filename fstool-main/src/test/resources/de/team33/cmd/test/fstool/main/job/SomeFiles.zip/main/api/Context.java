package de.team33.cmd.fstool.main.api;

public interface Context {

    void printf(String format, Object ... values);
}

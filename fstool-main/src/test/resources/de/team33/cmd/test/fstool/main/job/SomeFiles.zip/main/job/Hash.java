package de.team33.cmd.fstool.main.job;

import de.team33.cmd.fstool.main.api.BadRequestException;
import de.team33.cmd.fstool.main.api.Context;
import de.team33.patterns.exceptional.dione.Converter;
import de.team33.patterns.exceptional.dione.Wrapping;
import de.team33.patterns.serial.charon.Series;
import de.team33.tools.io.Hasher;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public class Hash implements Runnable {

    private static final Converter CNV = Converter.using(Wrapping.method(IllegalStateException::new));
    private static final String HELP_FORMAT = //
            "Expected request scheme:%n" +
            "%n" +
            "    %s hash [-r] KEEP PATH%n" +
            "%n" +
            "    to rename all regular files in a given target directory using a hash value%n" +
            "    previously calculated over their contents. The following files are ignored:%n" +
            "%n" +
            "    - Subdirectories and symbolic links%n" +
            "    - Files whose names start with a period%n" +
            "    - Files that have already been renamed this way%n" +
            "%n" +
            "Required arguments (case insensitive):%n" +
            "%n" +
            "    KEEP: a number of characters to keep from each original file name%n" +
            "    PATH: a path to the target directory.%n" +
            "%n" +
            "Optional argument (case insensitive):%n" +
            "%n" +
            "    -R: recursive processing of subdirectories.";
    private static final String PERIOD = ".";
    private static final Pattern TOUCHED = Pattern.compile("[^#]*#[0123456789abcdefABCDEF]{40}(\\.[^.]*){0,1}");

    private final Context context;
    private final Option option;
    private final Path tgtPath;
    private final int maxKeep;
    private final Hasher hasher = new Hasher(Hasher.Algorithm.SHA_1);

    private Hash(final Context context, final String shellCmd, final Option option, final List<String> args) {
        if (2 != args.size()) {
            throw new BadRequestException(String.format(HELP_FORMAT, shellCmd));
        }
        this.context = context;
        this.option = option;
        this.tgtPath = Paths.get(args.get(1)).toAbsolutePath().normalize();
        try {
            this.maxKeep = Integer.parseInt(args.get(0));
        } catch (final NumberFormatException ignored) {
            throw new BadRequestException(String.format(HELP_FORMAT, shellCmd));
        }
    }

    public static Runnable runnable(final Context context, final String shellCmd, final Series<String> args) {
        if (args.isCharged() && "-r".equalsIgnoreCase(args.head())) {
            return new Hash(context, shellCmd, Option.RECURSIVE, args.tail().asList());
        } else {
            return new Hash(context, shellCmd, Option.FLAT, args.asList());
        }
    }

    private static String normalExt(final String original) {
        return original.toLowerCase();
    }

    private static String normalPrfx(final String original) {
        return original.replace('#', '=').replace('.', '_');
    }

    @Override
    public void run() {
        run(tgtPath);
    }

    private void run(final Path parent) {
        CNV.run(() -> {
            try (final Stream<Path> stream = Files.list(parent)) {
                stream.peek(path -> context.printf("%s ... ", path))
                      .filter(this::isRegular)
                      .map(FileInfo::new)
                      .filter(this::isNormal)
                      .filter(this::isUntouched)
                      .forEach(fileInfo -> {
                          final String name = fileInfo.name;
                          final int dotIndex = name.lastIndexOf('.');
                          final String extension = normalExt((0 > dotIndex) ? "" : name.substring(dotIndex));
                          final int endIndex = Math.min(maxKeep, (0 > dotIndex) ? name.length() : dotIndex);
                          final String prefix = normalPrfx(name.substring(0, endIndex));
                          final String hash = hasher.hash(fileInfo.path);
                          final String newName = String.join("", prefix, "#", hash, extension);
                          context.printf("-> %s ... ", newName);
                          try {
                              Files.move(fileInfo.path, fileInfo.path.getParent().resolve(newName));
                              context.printf("ok%n");
                          } catch (IOException e) {
                              context.printf("failed - keeping original%n");

                          }
                      });
            }
        });
    }

    private boolean isUntouched(final FileInfo fileInfo) {
        if (TOUCHED.matcher(fileInfo.name).matches()) {
            context.printf("ignored (already hashed)%n");
            return false;
        } else {
            return true;
        }
    }

    private boolean isNormal(final FileInfo fileInfo) {
        if (fileInfo.name.startsWith(PERIOD)) {
            context.printf("ignored (special file)%n");
            return false;
        } else {
            return true;
        }
    }

    private boolean isRegular(final Path path) {
        if ((Option.RECURSIVE == option) && Files.isDirectory(path, LinkOption.NOFOLLOW_LINKS)) {
            context.printf("processing subdirectory%n");
            run(path);
            return false;
        } else if (!Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS)) {
            context.printf("ignored (no regular file)%n");
            return false;
        } else {
            return true;
        }
    }

    private enum Option {
        FLAT,
        RECURSIVE;
    }

    private static class FileInfo {

        final Path path;
        final String name;

        FileInfo(final Path path) {
            this.path = path;
            this.name = path.getFileName().toString();
        }
    }
}

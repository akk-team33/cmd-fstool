package de.team33.cmd.test.fstool.main;

import de.team33.cmd.fstool.main.Help;
import de.team33.cmd.fstool.main.Main;
import de.team33.cmd.fstool.main.api.Context;
import de.team33.patterns.testing.titan.io.Redirected;
import de.team33.patterns.io.alpha.TextIO;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class MainTest implements Context {

    public static final String ARG_0 = "./fstool.sh";
    public static final String UNKNOWN_CMD = "wdlbrmpft";

    /**
     * Ensures that {@link Main#main(String...)}, when called without arguments,
     * writes specific information to standard output.
     */
    @Test
    void main_noArgs() throws Exception {
        final String expected = String.format("%s%n%s%n%n",
                                              TextIO.read(Main.class, "head.txt"),
                                              TextIO.read(Main.class, "main.txt"));
        final String result = Redirected.outputOf(Main::main);
        assertEquals(expected, result);
    }

    /**
     * Ensures that {@link Main#main(String...)}, when called with a single argument,
     * writes a specific help message to standard output.
     */
    @Test
    void main_singleArg() throws Exception {
        final String format = "%s%nYour request was not recognized:%n%n    %s%n%n%s%n%n";
        final String expected = String.format(format,
                                              TextIO.read(Main.class, "head.txt"),
                                              ARG_0,
                                              Help.text(ARG_0));
        final String result = Redirected.outputOf(() -> Main.main(ARG_0));
        assertEquals(expected, result);
    }

    /**
     * Ensures that {@link Main#main(String...)}, when called with an unknown COMMAND argument,
     * writes a specific help message to standard output.
     */
    @Test
    void main_unknownCommand() throws Exception {
        final String expected = String.format("%s%nYour request was not recognized:%n%n    %s%n%n%s%n%n",
                                              TextIO.read(Main.class, "head.txt"),
                                              String.join(" ", ARG_0, UNKNOWN_CMD, "x", "y", "z"),
                                              Help.text(ARG_0));
        final String result = Redirected.outputOf(() -> Main.main(ARG_0, UNKNOWN_CMD, "x", "y", "z"));
        assertEquals(expected, result);
    }

    @Test
    void main_clean() throws Exception {
        final String expected = String.format("%s%nYour request was not recognized:%n%n    %s%n%n",
                                              TextIO.read(Main.class, "head.txt"),
                                              String.join(" ", ARG_0, "clean"));
        final String result = Redirected.outputOf(() -> Main.main(ARG_0, "clean"));
        assertTrue(result.startsWith(expected));
    }

    @Test
    void main_dcopy() throws Exception {
        final String expected = String.format("%s%nYour request was not recognized:%n%n    %s%n%n",
                                              TextIO.read(Main.class, "head.txt"),
                                              String.join(" ", ARG_0, "dcopy"));
        final String result = Redirected.outputOf(() -> Main.main(ARG_0, "dcopy"));
        assertTrue(result.startsWith(expected));
    }

    @Test
    void main_hash() throws Exception {
        final String expected = String.format("%s%nYour request was not recognized:%n%n    %s%n%n",
                                              TextIO.read(Main.class, "head.txt"),
                                              String.join(" ", ARG_0, "hash"));
        final String result = Redirected.outputOf(() -> Main.main(ARG_0, "hash"));
        assertTrue(result.startsWith(expected));
    }

    @Override
    public void printf(final String format, final Object... values) {
        System.out.printf(format, values);
    }
}

package de.team33.cmd.fstool.main;

import de.team33.cmd.fstool.main.api.BadRequestException;
import de.team33.cmd.fstool.main.api.Context;
import de.team33.patterns.serial.charon.Series;
import de.team33.patterns.io.alpha.TextIO;

public class Main implements Context {

    private final Runnable backing;

    private Main(final Series<String> args) {
        backing = args.ifCharged((head, tail) -> backing(this, head, tail))
                      .orElseThrow(() -> new BadRequestException(TextIO.read(getClass(), "main.txt")));
    }

    public static void main(final String... args) {
        try {
            new Main(Series.of(args)).run();
        } catch (final BadRequestException e) {
            System.out.printf("%s%n", TextIO.read(Main.class, "head.txt"));
            if (args.length > 0)
                System.out.printf("Your request was not recognized:%n%n    %s%n%n",
                                  String.join(" ", args));
            System.out.printf("%s%n%n", e.getMessage());
        }
    }

    private static Runnable backing(final Context context, final String shellCmd, final Series<String> args) {
        return args.ifCharged((head, tail) -> Command.runnable(context, shellCmd, head, tail))
                   .orElseThrow(() -> new BadRequestException(Help.text(shellCmd)));
    }

    private void run() {
        backing.run();
    }

    @Override
    public void printf(final String format, final Object... values) {
        System.out.printf(format, values);
    }
}

package de.team33.cmd.fstool.main.job;

import de.team33.cmd.fstool.main.api.BadRequestException;
import de.team33.cmd.fstool.main.api.Context;
import de.team33.patterns.exceptional.dione.Converter;
import de.team33.patterns.exceptional.dione.Wrapping;
import de.team33.patterns.serial.charon.Series;
import de.team33.tools.io.Hasher;

import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public class Hash implements Runnable {

    private static final Converter CNV = Converter.using(Wrapping.method(IllegalStateException::new));
    private static final String HELP_FORMAT = //
            "Expected request scheme:%n" +
                    "%n" +
                    "    %s hash TGT_PATH%n" +
                    "%n" +
                    "    to rename all regular files in a given target directory using a hash value%n" +
                    "    previously calculated over their contents. The following files are ignored:%n" +
                    "%n" +
                    "    - Subdirectories and symbolic links%n" +
                    "    - Files whose names start with a period%n" +
                    "    - Files that have already been renamed this way%n" +
                    "%n" +
                    "Required argument:%n" +
                    "%n" +
                    "    TGT_PATH: a path to the target directory.";
    private static final String PERIOD = ".";
    private static final Pattern TOUCHED = Pattern.compile("[^#]*#[0123456789abcdefABCDEF]{40}(\\.[^.]*){0,1}");

    private final Context context;
    private final Path tgtPath;
    private final Hasher hasher = new Hasher(Hasher.Algorithm.SHA_1);

    private Hash(final Context context, final String shellCmd, final List<String> args) {
        if (1 != args.size()) {
            throw new BadRequestException(String.format(HELP_FORMAT, shellCmd));
        }
        this.context = context;
        this.tgtPath = Paths.get(args.get(0)).toAbsolutePath().normalize();
    }

    public static Runnable runnable(final Context context, final String shellCmd, final Series<String> args) {
        return new Hash(context, shellCmd, args.asList());
    }

    @Override
    public void run() {
        CNV.run(() -> {
            try (final Stream<Path> stream = Files.list(tgtPath)) {
                stream.peek(path -> context.printf("%s ... ", path))
                      .filter(this::isRegular)
                      .map(FileInfo::new)
                      .filter(this::isNormal)
                      .filter(this::isUntouched)
                      .forEach(CNV.consumer(fileInfo -> {
                          final String name = fileInfo.name;
                          final int dotIndex = name.lastIndexOf('.');
                          final String extension = normalExt((0 > dotIndex) ? "" : name.substring(dotIndex));
                          final int endIndex = Math.min(8, (0 > dotIndex) ? name.length() : dotIndex);
                          final String prefix = normalPrfx(name.substring(0, endIndex));
                          final String hash = hasher.hash(fileInfo.path);
                          final String newName = String.join("", prefix, "#", hash, extension);
                          context.printf("-> %s ... ", newName);
                          Files.move(fileInfo.path, fileInfo.path.getParent().resolve(newName));
                          context.printf("ok%n");
                      }));
            }
        });
    }

    private String normalExt(final String original) {
        return original.toLowerCase();
    }

    private String normalPrfx(final String original) {
        return original.replace('#', '=').replace('.', '_');
    }

    private boolean isUntouched(final FileInfo fileInfo) {
        if (TOUCHED.matcher(fileInfo.name).matches()) {
            context.printf("ignored (already hashed)%n");
            return false;
        } else {
            return true;
        }
    }

    private boolean isNormal(final FileInfo fileInfo) {
        if (fileInfo.name.startsWith(PERIOD)) {
            context.printf("ignored (special file)%n");
            return false;
        } else {
            return true;
        }
    }

    private boolean isRegular(final Path path) {
        if (!Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS)) {
            context.printf("ignored (no regular file)%n");
            return false;
        } else {
            return true;
        }
    }

    private static class FileInfo {

        final Path path;
        final String name;

        FileInfo(final Path path) {
            this.path = path;
            this.name = path.getFileName().toString();
        }
    }
}

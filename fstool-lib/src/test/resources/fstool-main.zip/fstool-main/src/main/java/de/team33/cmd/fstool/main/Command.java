package de.team33.cmd.fstool.main;

import de.team33.cmd.fstool.main.api.BadRequestException;
import de.team33.cmd.fstool.main.api.Context;
import de.team33.cmd.fstool.main.job.Clean;
import de.team33.cmd.fstool.main.job.DirCopy;
import de.team33.cmd.fstool.main.job.Hash;
import de.team33.cmd.fstool.main.job.MKDate;
import de.team33.cmd.fstool.main.job.MKTime;
import de.team33.patterns.serial.charon.Series;

import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public enum Command {

    DCOPY("Copy the subdirectory structure from one directory to another.",
          ini -> DirCopy.runnable(ini.context, ini.shellCmd, ini.args)),
    MKDATE("Create a directory named according to the current local date.",
           ini -> MKDate.runnable(ini.context, ini.shellCmd, ini.args)),
    MKTIME("Create a directory named according to the current local time.",
           ini -> MKTime.runnable(ini.context, ini.shellCmd, ini.args)),
    CLEAN("Remove all empty directories within a given directory substructure.",
          ini -> Clean.runnable(ini.context, ini.shellCmd, ini.args)),
    HASH("Use a previously calculated hash to rename files.",
          ini -> Hash.runnable(ini.context, ini.shellCmd, ini.args));

    private static final String NEW_LINE = String.format("%n    ");

    private final String outline;
    private final Function<Initial, Runnable> toRunnable;

    Command(final String outline, final Function<Initial, Runnable> toRunnable) {
        this.outline = outline;
        this.toRunnable = toRunnable;
    }

    public static String outline() {
        return Stream.of(values())
                     .map(cmd -> cmd.name() + ": " + cmd.outline)
                     .collect(Collectors.joining(NEW_LINE));
    }

    static Runnable runnable(final Context context,
                             final String shellCmd,
                             final String command,
                             final Series<String> args) {
        return Stream.of(values())
                     .filter(cmd -> cmd.name().equalsIgnoreCase(command))
                     .findAny()
                     .map(cmd -> cmd.toRunnable.apply(new Initial(context, shellCmd, args)))
                     .orElseThrow(() -> new BadRequestException(Help.text(shellCmd)));
    }

    private record Initial(Context context,
                           String shellCmd,
                           Series<String> args) {
    }
}

package de.team33.cmd.fstool.main;

public class Help {

    private static final String FORMAT = "Expected request scheme:%n" +
            "%n" +
            "    %1$s COMMAND [arg [, arg [, ...]]]%n" +
            "%n" +
            "Available COMMANDs (case insensitive):%n" +
            "%n" +
            "    %2$s";

    public static String text(final String shellCmd) {
        return String.format(FORMAT, shellCmd, Command.outline());
    }
}

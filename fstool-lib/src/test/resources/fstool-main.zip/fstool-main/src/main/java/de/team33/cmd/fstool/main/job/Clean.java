package de.team33.cmd.fstool.main.job;

import de.team33.cmd.fstool.main.api.Context;
import de.team33.cmd.fstool.main.api.BadRequestException;
import de.team33.patterns.serial.charon.Series;

import javax.swing.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public final class Clean implements Runnable {

    private static final String HELP_FORMAT = "Expected request scheme:%n" +
                                              "%n" +
                                              "    %s clean [-dry] PATH [, PATH [, ...]]%n" +
                                              "%n" +
                                              "    to remove each PATH if it is an empty directory%n" +
                                              "    after cleaning all its subdirectories.%n" +
                                              "%n" +
                                              "Option:%n" +
                                              "%n" +
                                              "    -dry: Just show what needs to be done. Remove nothing.";

    private final Context context;
    private final Mode mode;
    private final List<Path> paths;

    private Clean(final Context context, final Mode mode, final List<String> paths) {
        this.context = context;
        this.mode = mode;
        this.paths = paths.stream()
                          .map(Paths::get)
                          .map(Path::toAbsolutePath)
                          .map(Path::normalize)
                          .map(path -> assertDirectory(context, path))
                          .filter(Objects::nonNull)
                          .collect(Collectors.toList());
        if (this.paths.isEmpty())
            context.printf("NOTHING TO DO%n    no directories found in %s%n", paths);
    }

    private static Path assertDirectory(final Context context, final Path path) {
        if (Files.isDirectory(path)) {
            return path;
        }
        context.printf("IGNORED (not a directory):%n    %s%n", path);
        return null;
    }

    public static Runnable runnable(final Context context, final String shellCmd, final Series<String> args) {
        return args.ifCharged((head, tail) -> onChargedArgs(context, shellCmd, args, head, tail))
                   .orElseThrow(() -> newBadRequestException(shellCmd));
    }

    private static Runnable onChargedArgs(final Context context, final String shellCmd,
                                          final Series<String> args, final String head,
                                          final Series<String> tail) {
        return "-dry".equalsIgnoreCase(head)
               ? dryRunnable(context, shellCmd, tail)
               : new Clean(context, Mode.REAL, args.asList());
    }

    private static Runnable dryRunnable(final Context context, final String shellCmd, final Series<String> args) {
        if (args.isCharged())
            return new Clean(context, Mode.DRY, args.asList());
        else
            throw newBadRequestException(shellCmd);
    }

    private static BadRequestException newBadRequestException(String shellCmd) {
        return new BadRequestException(String.format(HELP_FORMAT, shellCmd));
    }

    private static void delete(final Path path) {
        try {
            Files.delete(path);
        } catch (IOException e) {
            throw new IllegalStateException(e.getMessage(), e);
        }
    }

    @Override
    public void run() {
        clean(paths);
    }

    private List<Path> clean(final List<Path> paths) {
        return paths.stream()
                    .filter(Files::isDirectory)
                    .map(this::clean)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());
    }

    private Path clean(final Path path) {
        final List<Path> content = list(path);
        final List<Path> deleted = clean(content);
        content.removeAll(deleted);
        if (content.isEmpty()) {
            context.printf("%s ...", path);
            mode.job.accept(path);
            context.printf(" %s%n", mode.done);
            return path;
        } else {
            return null;
        }
    }

    private List<Path> list(final Path path) {
        try (final Stream<Path> stream = Files.list(path)) {
            return stream.collect(Collectors.toCollection(LinkedList::new));
        } catch (IOException e) {
            throw new IllegalStateException(e.getMessage(), e);
        }
    }

    private enum Mode {

        DRY(path -> {
        }, "to be deleted"),
        REAL(Clean::delete, "deleted");

        final Consumer<Path> job;
        final String done;

        Mode(final Consumer<Path> job, final String done) {
            this.job = job;
            this.done = done;
        }
    }
}
